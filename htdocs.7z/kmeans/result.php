<?php
/**
 * Created by PhpStorm.
 * User: Rudi
 * Date: 30/09/2018
 * Time: 16.45
 */

session_start();

require_once __DIR__ . '/vendor/autoload.php';

include 'app.php';

if(!isset($_GET['number'])){
    header("location:./index.php");
}

$nilaik = $_GET['number'];
$_SESSION['k'] = $nilaik;


$classifier = new Phpml\Clustering\KMeans($nilaik);

print_r($classifier->cluster($data));

?>

<hr>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contoh Chart</title>
    <style>
        body {
            font-family: 'Open Sans', sans-serif;
        }

        .graph .labels.x-labels {
            text-anchor: middle;
        }

        .graph .labels.y-labels {
            text-anchor: end;
        }

        .graph {
            height: 500px;
            width: 800px;
        }

        .graph .grid {
            stroke: #ccc;
            stroke-dasharray: 0;
            stroke-width: 1;
        }

        .labels {
            font-size: 13px;
        }

        .label-title {
            font-weight: bold;
            text-transform: uppercase;
            font-size: 12px;
            fill: black;
        }

        .data {
            fill: red;
            stroke-width: 1;
        }
    </style>
</head>
<body>


<svg version="1.2" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" class="graph" aria-labelledby="title" role="img">
    <title id="title">A line chart showing some information</title>
    <g class="grid x-grid" id="xGrid">
        <line x1="90" x2="90" y1="5" y2="371"></line>
    </g>
    <g class="grid y-grid" id="yGrid">
        <line x1="90" x2="705" y1="370" y2="370"></line>
    </g>
    <g class="labels x-labels">
        <text x="10" y="10">2008</text>
        <text x="20" y="20">2009</text>
        <text x="30" y="30">2010</text>
        <text x="40" y="40">2011</text>
        <text x="50" y="50">2012</text>
        <!--<text x="400" y="440" class="label-title">Year</text>-->
    </g>
    <g class="labels y-labels">
        <text x="10" y="10">15</text>
        <text x="20" y="20">10</text>
        <text x="30" y="30">5</text>
        <text x="40" y="40">0</text>
        <text x="50" y="50">0</text>
        <!--<text x="50" y="200" class="label-title">Price</text>-->
    </g>
    <g class="data" data-setname="Our first data set">
        <circle cx="110" cy="192" data-value="10.2" r="4"></circle>
        <circle cx="240" cy="141" data-value="8.1" r="4"></circle>
        <circle cx="388" cy="179" data-value="7.7" r="4"></circle>
        <circle cx="531" cy="200" data-value="6.8" r="4"></circle>
        <circle cx="677" cy="104" data-value="6.7" r="4"></circle>
    </g>
</svg>


</body>
</html>
