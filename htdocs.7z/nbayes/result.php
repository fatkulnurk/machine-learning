<!DOCTYPE html>
<html>
<head>
    <title>Hayo Bisa main apa gk</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="./asset/bulma-0.7.1/css/bulma.min.css" media="all">
</head>
<body>
<div class="hero is-link is-bold is-is-medium fullwidth">
    <div class="hero-body">
        <div class="container has-text-centered">
            <p></p>
            <br>
            <h1 class="title">Hasil Perhitungan</h1>
        </div>
    </div>
</div>
<?php

session_start();

require_once __DIR__ . '/vendor/autoload.php';

use Phpml\Classification\NaiveBayes;
use Phpml\Classification;
include 'app.php';

if(isset($_GET['cuaca']) && isset($_GET['temperatur']) && isset($_GET['kecepatan'])){
    $cuaca      = $_GET['cuaca'];
    $temperatur = $_GET['temperatur'];
    $kecepatan  = $_GET['kecepatan'];
}else{
    header("location:./index.php");
}

$classifier = new NaiveBayes();
$classifier->train($data, $label);

//print_r($classifier);

//echo json_decode($classifier);

//echo var_dump($classifier->getP());

echo '<hr>';

$hasil = $classifier->getP();
$py = $hasil['ya'];
$pt = $hasil['tidak'];

print_r($hasil);

echo '<hr>';
$hasilpredict = $classifier->predictCoba([$cuaca,$temperatur,$kecepatan]);

print_r($hasilpredict);
$ypre  = $hasilpredict['ya'];
$tpre  = $hasilpredict['tidak'];


echo '<hr>Prob Ya : '.$ypre/$pt;
echo '<hr>Prob Tidak : '.$tpre/$py;

$result =  $classifier->predict([$cuaca,$temperatur,$kecepatan]);

$benar=0;
echo '
<div class="container has-text-centered">
<p>
        Cuaca '.$cuaca.' - Temperatur '.$temperatur.' - Kecepatan '.$kecepatan.'
</p>
</div>
<div class="section">
    <div class="columns">
        <div class="column is-4 is-offset-4 box">

';
if($result == 'ya'){
    echo '<h1 class="title">YA - bisa main golf</h1>';
}else{
    echo '<h1 class="title">Tidak bisa main golf</h1>';
}

?>

        </div>
    </div>
</div>

</body>
</html>
